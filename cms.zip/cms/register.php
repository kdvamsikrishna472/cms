<!Doctype html>

<html>
<?php
 include("config/db.php");
 session_start();
  ?>

<head>
	<meta charset="UTF-8">
	<meta name="Author" content="SAM">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
	<link rel="stylesheet" href="css/fontawesome.min.css" type="text/css">
	<link rel="stylesheet" href="css/admin.css" type="text/css">
	<title> Login </title>

<body>
	<center>
		<div class="box">
			<h1 style="font-weight: bold"> Admin <span style="color: blue"> Registration panel </span> </h1>
		</div>
		<br>
		<br>


		<div class="box">
			<h1>Sign Up</h1>

			<form method="post" enctype="multipart/form-data">
				<div class="tbox">
					<input type="text" name="username" placeholder="username" value="">
				</div>
				<br>
				<br>
				<div class="tbox">
					<input type="password" name="password" placeholder="password" value="">
				</div>
				<br>
				<br>
				<input class="btn btn-primary" type="submit" name="Register" value="SIGN UP">
			</form>
		</div>
	</center>
</body>
</head>
</html>
<?php
if(isset($_POST['Register'])){
	$username=$_POST['username'];
	$password=$_POST['password'];

	$query2="insert into admin (username,password) values('$username','$password')";
	$runquery2=mysqli_query($con,$query2);
	if($runquery2){
		echo'<script>alert("Account has been register")</script>';
		header('location:login.php');
		$_SESSION['username']=$username;
		
	}
}


?>
