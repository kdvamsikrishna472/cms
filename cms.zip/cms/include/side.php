<?php
	include("config/db.php");
?>
<div class="col-md-4">
	<div class="valor1">
		<span class="valor">
			<center>
				<h3>latest post</h3>
			</center>
		</span>
	</div>
	<br>
	<center>
	<div class="row">

		<div class=col-md-8> <img class="rounded" src="img/late.jpg" style="width: 100px;
	height: 80px padding: 5px;">
		</div>
		<div class=col-md-8> <br> <span class="side_post"><a href="index.php"> Latest News </a> </span> </div>
	</div>
	<br>

	<div class="row">

		<div class=col-md-12> <img class="rounded" src="img/po.jpg" style="width: 100px;
	height: 80px padding: 5px;">
		</div>
		<div class=col-md-8> <br> <span class="side_post"><a href="index.php"> Coming up</a> </span> </div>
	</div>
	<br>
	</center>
	
	
	
	<!--<div class="valor1">
		<span class="valor">
			<center>
				<h3>Categories</h3>
			</center>
		</span>
	</div>
	<div class="cat">
		<?php
	  $cat="select * from cat order by id Desc";
	  $run_cat=mysqli_query($con,$cat);
	  $count_cat=mysqli_num_rows($run_cat);
	  if($count_cat>0)
	  {
		  while($row_cat=mysqli_fetch_array($run_cat))
		  {
			$id_cat=$row_cat['id'];			
			$name_cat=$row_cat['name'];			
		 
		  ?>
		<a href="index.php" id=<?php echo $id_cat ?>" style="background:darkgray";"><?php echo $name_cat ?> </a>
		<?php }}
	  
	  else
	  {
		  echo "<center> <h5> Sorry No categories available </h5> </center>";
	  }
	  ?>-->
