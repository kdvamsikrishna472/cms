<div class="footer">
  <p>Copyright @ 2019 <span class="valor">VAMSI</span></p>
</div>