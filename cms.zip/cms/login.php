<html>
<?php
	include("config/db.php");
	session_start();
	?>

<head>
	<meta charset="UTF-8">
	<meta name="Author" content="VAMSI">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
	<link rel="stylesheet" href="css/fontawesome.min.css" type="text/css">
	<link rel="stylesheet" href="css/admin.css" type="text/css">
	<title> Login </title>
</head>

<body>
	<center>
		<div class="box">
			<center>

				<h1 style="font-weight: bold"> Admin <span style="color: blue"> Login Panel </span> </h1>
			</center>
		</div>
		<br>
		<br>
		<div class="box">
			<h1>LOG IN</h1>

			<form method="post" enctype="multipart/form-data">
				<div class="tbox">
					<input type="text" name="username" placeholder="username" value="">
				</div>
				<br>
				<br>
				<div class="tbox">
					<input type="password" name="password" placeholder="password" value="">
				</div>
				<br>
				<br>
				<input class="btn btn-primary" type="submit" name="SignIn" value="LOG IN">
			</form>
			<a class="b2" href="register.php">CREATE ACCOUNT</a>
		</div>
	</center>
</body>

</html>
<?php
if(isset($_POST['SignIn'])){
	$username=$_POST['username'];
	$password=$_POST['password'];
	$query1= "select * from admin where username='$username' AND password='$password'";
	$runquery1=mysqli_query($con,$query1);
	if(mysqli_num_rows($runquery1)>0){
		header('location:dashboard.php');
		$_SESSION['username']=$username;
		
	}
	else{
		echo'<script>alert("Invalid username and password")</script>';
	}
}
?>
