admin username:vamsi
admin password:admin

 1. copy everything and paste in C:\xampp\htdocs
 
 2. create "cms" in database and import files from database

 3. open browser then type url localhost/cms/login.php to enter login page then type username and password
 
 4.  to enter blog localhost/cms/index.php
 
 
 thank you.....